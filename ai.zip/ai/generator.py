import asyncio

from fastapi import WebSocket

from unsloth import FastLanguageModel

from langchain_ollama import ChatOllama
from langchain_core.output_parsers import StrOutputParser
from langchain.prompts import ChatPromptTemplate

from utils import attack_map

hacker_template = '''You are an expert hacker and exploit developer. Generate only the attack payload for this vulnerability. No additional text or descriptions - just tell us what we need to enter.
{context}

Question: {question}
'''

template = '''Below is an instruction that describes a task. Write a response that appropriately completes the request.
{context}

Question: {question}
'''
prompt = ChatPromptTemplate.from_template(template)

async def process_chat(question: str, context: str) -> str:
    llm = ChatOllama(model='llama3-ko', temperature=0.9)

    input_data = {
        'context' : context,
        'question' : question
    }

    chain = prompt | llm | StrOutputParser()
    # output = chain.invoke(input_data)
    output = await asyncio.to_thread(lambda: chain.invoke(input_data))
    print(output)

    return output

async def process_fuzz_payload(attack: str):
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name = ""
    )